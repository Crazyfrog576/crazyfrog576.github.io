A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/PpBYQJ.

 A personal website built using HTML, CSS & JS, with General Assembly at the Smartgen Conference 2017.